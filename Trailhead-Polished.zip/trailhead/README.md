# Trailhead — complete planning flow

## Hackathon polish update

This update bundles Leaflet locally, preserves map center/zoom across day and mode changes, adds a coordinate jump and fit-route control, makes parking draggable, displays approximate route distance, and reports tile-loading failures. Basemap tiles still require internet. Copy the ENTIRE `static` folder, including `static/vendor/leaflet`, when installing.

The updated trip screen polls status every five seconds while visible, shows a timestamped handoff log, and offers a downloadable text packet. The profile and home screens have a one-click fictional demo. No notifications or emergency calls are sent.

The review screen now includes a deterministic preflight checklist with links to fix missing planning fields. This is a completeness check, not a safety rating.

### Optional Gemini review

The optional AI explanation requires a `GEMINI_API_KEY` environment variable. Set it on your own machine using your provider's secure instructions, then restart Flask. Do not paste keys into chat, commit them to Git, or include them in a submission. `GEMINI_MODEL` can override the configured model, whose default is `gemini-3.8-flash` based on the current official text-generation example.

Only activity type, trip/food day counts, and a checklist of missing fields go to Gemini after the user clicks the AI review button. Names, contacts, health data, written route text, and coordinates are excluded from this request. The adapter has NOT been tested against a live model here. If no key is configured or the model is unavailable, the interface explicitly labels the rules-based fallback. Do not claim a working Gemini integration or enter an AI sponsor track until you test it successfully.

### Fastest demo

Launch the fictional demo from the setup or home page. Open its contact link in a second tab, acknowledge the plan, and return to the organizer. The status updates within five seconds. Simulate overdue, show the agreed instructions, and mark yourself back safe. The open contact view updates automatically. The demo itinerary is illustrative, not a validated navigation route.

### Verification for this update

Backend checks passed for demo creation, acknowledgments, status events, overdue/safe transitions, packet download, CSRF, and local asset delivery. DOM-level checks using real Leaflet passed for map point entry, preserved zoom, parking, day switching, preflight fallback, trip saving, and excluded health data. Full visual browser rendering and real map-tile delivery still need checking on your computer.

The code has not been pushed to your GitHub repository or deployed by this update. Install it locally, test it, and publish the correct source/demo links before submission.

## Install on your computer

1. Stop the running Flask app with Ctrl+C in its terminal.
2. Back up your current project folder.
3. Extract this ZIP. Copy the contents of its `trailhead` folder into your project folder, replacing `app.py`, `templates/base.html`, `templates/create.html`, `templates/trip.html`, and `static/style.css`. Also copy the NEW `templates/join.html` and `static/app.js` files.
4. Keep your existing `trailhead.sqlite3` file. This update adds tables without deleting existing trips.
5. In your project terminal, run:

```sh
python -m pip install -r requirements.txt
python app.py
```

If your computer uses `python3`, use that in both commands instead.

6. Open http://localhost:5000 and refresh with Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac).
7. Complete the one-time profile setup, then choose Plan a trip.

## Included

- Four-step saved profile: personal details, optional health information, vehicle, and one or two emergency contacts.
- Home with active and completed trips created by this browser.
- Four-step trip planner: dates/activity, daily map routes and parking, food/shelter/communication, and companions.
- Click-to-mark routes or drag-to-draw mode; independent routes for each day, undo, clear, location centering, and a parking pin.
- Written itinerary fallback when external map services cannot load.
- Editable review summary and contact selection.
- Separate contact links, copy-to-clipboard, prepared text and email drafts.
- Per-trip opt-in for the organizer's saved health details. Omitted details are not copied into the trip record.
- Group invitation link after trip creation; companions use their own browser profile and explicitly opt into health sharing when joining.
- Individual contact acknowledgments, overdue simulation, safe check-in, and printable trip packet.

## Demo flow

Create a profile with fictional details. Plan a trip, review it, and create contact links. Open a contact link in a second tab and acknowledge it. Refresh the organizer page to see the acknowledgment. Simulate overdue, then mark yourself back safe. Refresh the contact page to see the safe status.

For a group invitation demo, open the invitation in an incognito window, create the companion's profile, then return to the invitation and join. The organizer and contacts will see that member after refreshing.

## Current implementation limits

- Text and email buttons open your device's messaging applications. They do not send messages on the server or confirm delivery. Copy-link sharing works without a messaging provider. Automatic safe-return messages and overdue alerts are not implemented.
- `localhost` links work only on your computer. Deploy Flask on a public HTTPS host before sharing links with other devices. This package does not deploy the project.
- Profiles are saved in SQLite and tied to a signed browser cookie lasting up to one year. There is no account login or cross-device recovery. Clearing cookies disconnects the browser from its profile. Keep `.session-secret` when restarting or deploying to preserve sessions, or set a stable `SECRET_KEY` environment variable. Do not commit secrets or the SQLite database to Git.
- Health details are optional and not end-to-end encrypted. Anyone holding a contact or organizer link can read the health details explicitly included in that trip. Use fictional data for the hackathon demo.
- Group members can join and contribute their own details, but collaborative route editing is not implemented. Invitation links are created after review, instead of during the planner.
- Routes are approximate lines, not directions or live tracking. Leaflet, OpenStreetMap tiles, and optional web fonts require internet access.
- Old trip URLs remain functional. Trips created before browser profiles were added will not automatically appear in the new home screen; retain their organizer URLs.
- The review screen edits a plan before creating it. Existing trip details cannot yet be edited after creation; create another plan if needed.

## Checks performed

Server checks cover saving profiles, CSRF rejection, two-contact acknowledgment, health exclusion/inclusion, group joining with separate consent, blocking joins after safe check-in, overdue/safe transitions, and invalid coordinate rejection.

The setup → planner → review/edit → sharing → saved-home flow also passed an automated DOM test, including the map-unavailable fallback. Python and JavaScript syntax checks passed. Visual browser rendering and live map drawing were not verified in this environment because the browser download failed.
