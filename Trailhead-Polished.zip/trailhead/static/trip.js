'use strict';
const config=JSON.parse(document.getElementById('trip-config').textContent);
const routeMap=TrailMaps.create('map',config.parking||config.points[0]||[37.38,-80.08]);
if(routeMap){
 const days=config.days.length?config.days:[config.points];
 days.forEach((day,i)=>{L.polyline(day,{color:TrailMaps.colors[i%4],weight:4}).addTo(routeMap).bindTooltip('Day '+(i+1));if(day.length)L.circleMarker(day.at(-1),{radius:6,color:TrailMaps.colors[i%4]}).addTo(routeMap).bindTooltip('Day '+(i+1)+' end');});
 if(config.parking)L.marker(config.parking).addTo(routeMap).bindTooltip('Parking');
 const bounds=config.points.concat(config.parking?[config.parking]:[]);
 if(bounds.length)routeMap.fitBounds(bounds,{padding:[30,30],maxZoom:15});
}
document.querySelectorAll('time').forEach(el=>el.textContent=new Date(el.dateTime).toLocaleString());
document.querySelectorAll('.copy-link').forEach(b=>b.onclick=async()=>{try{await navigator.clipboard.writeText(b.parentElement.querySelector('input').value);b.textContent='Copied';}catch{b.textContent='Select and copy the link';}});
function tick(){if(config.safe||config.demo)return;const delta=new Date(config.deadline)-Date.now();document.getElementById('countdown').textContent=(delta<0?'Overdue by ':'Time to return: ')+Math.floor(Math.abs(delta)/3600000)+'h '+Math.floor(Math.abs(delta)/60000)%60+'m';}
tick();setInterval(tick,1000);
async function sync(){
 try{
  const r=await fetch(config.statusUrl);if(!r.ok)throw new Error('Not connected');const s=await r.json();
  if(Number(s.safe)!==config.safe||Number(s.demo)!==config.demo||Number(s.accepted)!==config.accepted||s.overdue!==config.overdue||s.members!==config.members){location.reload();return;}
  const list=document.getElementById('timeline');list.replaceChildren();
  s.events.forEach(e=>{const li=document.createElement('li');li.textContent=e.detail;const t=document.createElement('small');t.textContent=new Date(e.at).toLocaleTimeString();li.append(t);list.append(li);});
  if(!s.events.length){const li=document.createElement('li');li.textContent='No activity recorded yet.';list.append(li);}
  document.getElementById('sync-state').textContent='● Updated '+new Date().toLocaleTimeString();
 }catch{document.getElementById('sync-state').textContent='○ Offline · status may be out of date';}
}
sync();setInterval(()=>{if(!document.hidden)sync();},5000);
