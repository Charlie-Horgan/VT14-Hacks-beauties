'use strict';
window.TrailMaps = {
  create(id, center, zoom=12) {
    if (!window.L) return null;
    const m=L.map(id,{zoomControl:true,doubleClickZoom:false}).setView(center,zoom);
    const tiles=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
      maxZoom:19,attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(m);
    let errors=0, loaded=0;
    const report=()=>{
      const el=document.getElementById('map-network');
      if(el){el.hidden=false;el.textContent=loaded?'Some map tiles did not load. Check your connection.':'Basemap unavailable. Check your connection. Saved coordinates remain available; do not use the blank map for navigation.';}
    };
    tiles.on('tileerror',()=>{errors++;if(errors>=2)report();});
    tiles.on('tileload',()=>{loaded++;const el=document.getElementById('map-network');if(el&&loaded>errors)el.hidden=true;});
    m.whenReady(()=>requestAnimationFrame(()=>m.invalidateSize()));
    if(window.ResizeObserver){const observer=new ResizeObserver(()=>m.invalidateSize());observer.observe(m.getContainer());m.on('unload',()=>observer.disconnect());}
    return m;
  },
  distance(points) {
    let distance=0;
    for(let i=1;i<points.length;i++) distance+=L.latLng(points[i-1]).distanceTo(L.latLng(points[i]));
    return (distance/1609.344).toFixed(1);
  },
  colors:['#b8522b','#28695e','#78619a','#8c701e']
};
