'use strict';
const root = document.getElementById('app');
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const esc = escapeHTML;
let mapView=null;
let me, profile, screen='home', step=0, trip, result, map, layers, day=0, mode='route', drawMode=false, busy=false;
const csrf=document.querySelector('meta[name="csrf-token"]').content;
async function api(path, body) {
 const response=await fetch(path, body === undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)});
 let data; try {data=await response.json();} catch {throw new Error('Please reload the page and try again.');}
 if(!response.ok) throw new Error(data.error || 'Could not save. Please try again.');
 return data;
}
function error(message){let box=document.getElementById('error');if(box){box.textContent=message;box.hidden=false;box.scrollIntoView({block:'nearest'});}}
const input=(label,key,value='',type='text',required=false)=>`<label>${label}<input data-key="${key}" type="${type}" value="${esc(value)}" ${required?'required':''}></label>`;
const area=(label,key,value='',required=false)=>`<label>${label}<textarea data-key="${key}" ${required?'required':''}>${esc(value)}</textarea></label>`;
function chips(label,key,values,current){return `<label>${label}</label><div class="chips">${values.map(v=>`<button type="button" class="chip ${v===current?'selected':''}" data-choice="${key}" data-value="${esc(v)}">${esc(v)}</button>`).join('')}</div>`;}
function frame(title,sub,body,button,back=true,total=4){
 root.innerHTML=`<form id="wizard" novalidate><div class="step-top">${back?'<button type="button" class="back" data-action="back" aria-label="Go back">‹</button>':'<span></span>'}<span>${step<total?`STEP ${step+1} OF ${total}`:''}</span></div>${step<total?`<div class="progress">${Array.from({length:total},(_,i)=>`<i class="${i<=step?'filled':''}"></i>`).join('')}</div>`:''}<h1>${title}</h1><p class="muted">${sub}</p><div id="error" class="alert" hidden></div>${body}<div class="wizard-bottom"><button class="primary wide" ${busy?'disabled':''}>${button}</button></div></form>`;
 bind();
}
function collect(){
 const target=screen==='profile'?profile:trip;
 root.querySelectorAll('[data-key]').forEach(el=>{
  const k=el.dataset.key;
  if(k.startsWith('contact.')){const [,i,field]=k.split('.');profile.contacts[i][field]=el.value;}
  else target[k]=el.type==='checkbox'?el.checked:el.value;
 });
}
function valid(){const f=document.getElementById('wizard');if(!f.reportValidity())return false;collect();return true;}
function localDate(d){return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16);}
function newTrip(){const d=new Date();d.setMinutes(0,0,0);d.setHours(d.getHours()+1);const end=new Date(d);end.setDate(end.getDate()+1);end.setHours(18);return {name:'',activity:'Backpacking',departureLocal:localDate(d),deadlineLocal:localDate(end),duration:2,days:[[],[]],parking:null,route:'',vehicle:[profile.color,profile.make,profile.model,profile.plate,profile.state,profile.vehicle_notes].filter(Boolean).join(' '),food:2,shelter:'Tent',shelterColor:'Orange',messenger:false,groupMode:'Just me',group:'',instructions:'',selected:[0],include_health:false,channel:'Link'};}
function render(){
 if(map){mapView={center:[map.getCenter().lat,map.getCenter().lng],zoom:map.getZoom()};map.remove();map=null;}
 root.classList.toggle('map-editor',screen==='plan'&&step===1);
 if(screen==='profile') renderProfile(); else if(screen==='home') renderHome(); else if(screen==='setupDone') renderSetupDone(); else if(screen==='plan')renderPlan();else if(screen==='review')renderReview();else if(screen==='send')renderSend();else renderReady();
 window.scrollTo({top:0,behavior:'instant'});
}
function renderProfile(){
 const titles=["Let’s set you up once.",'Health basics','Your vehicle','Who should we call first?'];
 const subs=['Save your details so future trip plans take less time.','Optional. Choose whether to include these details when sharing a trip.','Help your contact identify the car at the trailhead. You can change this per trip.','Save up to two people who will be expecting you back.'];
 let body='';
 if(step===0)body=input('Full name','name',profile.name,'text',true)+input('Date of birth (optional)','dob',profile.dob,'date')+input('Mobile number','phone',profile.phone,'tel')+input('Email','email',profile.email,'email');
 if(step===1)body=area('Allergies','allergies',profile.allergies)+area('Conditions and past injuries','conditions',profile.conditions)+input('Medications','medications',profile.medications)+input('Height','height',profile.height)+input('Blood type (if known)','blood',profile.blood)+`<p class="small">Saved in this app’s database, associated with this browser. This prototype does not provide end-to-end encryption. You can leave these fields blank.</p>`;
 if(step===2)body=`<div class="row">${input('Make','make',profile.make)}${input('Model','model',profile.model)}</div>`+chips('Color','color',['White','Black','Silver','Gray','Blue','Red','Green','Tan'],profile.color)+`<div class="row">${input('License plate','plate',profile.plate)}${input('State','state',profile.state)}</div>`+input('Anything that stands out','vehicle_notes',profile.vehicle_notes);
 if(step===3)body=profile.contacts.map((c,i)=>`<section class="contact-card"><span class="eyebrow">CONTACT ${i+1}</span>${input('Name',`contact.${i}.name`,c.name,'text',true)}${input('Relationship',`contact.${i}.relationship`,c.relationship)}${input('Phone',`contact.${i}.phone`,c.phone,'tel')}${input('Email',`contact.${i}.email`,c.email,'email')}${i?'<button type="button" class="secondary" data-action="removeContact">Remove second contact</button>':''}</section>`).join('')+(profile.contacts.length<2?'<button type="button" class="secondary wide" data-action="addContact">＋ Add a second contact</button>':'')+'<p class="small">Nothing is sent when you save your profile.</p>';
 frame(titles[step],subs[step],body,step===3?'Finish setup':'Continue',true);if(step===0){root.querySelector('.wizard-bottom').insertAdjacentHTML('beforeend','<button type="button" class="secondary wide" data-action="demo">Explore a fictional demo trip</button>');bind();}
}
function renderSetupDone(){root.innerHTML=`<div class="success-mark">✓</div><h1>You’re all set.</h1><p class="muted">Your profile is saved. Next time, start with your trip.</p><div class="summary">${['About you','Health basics','Vehicle','Emergency contacts'].map(s=>`<div>${s}<span>✓</span></div>`).join('')}</div><button class="primary wide" data-action="home">Back to home →</button>`;bind();}
function renderHome(){
 root.innerHTML=`<h1>${me.trips.some(t=>!t.safe)?'Enjoy the trail.':'Where to next?'}</h1><p class="muted">Plan your trip, then share it with the people who will be waiting.</p><button class="plan-card" data-action="new"><span>Plan a trip</span><small>Four quick questions.</small><b>→</b></button><div class="eyebrow">YOUR TRIPS</div>${me.trips.length?me.trips.map(t=>`<article class="contact-card"><span class="eyebrow">${t.safe?'BACK SAFELY':t.overdue?'RETURN DEADLINE PASSED':t.accepted?'PLAN ACKNOWLEDGED':'WAITING FOR ACKNOWLEDGMENT'}</span><h2>${esc(t.name)}</h2><p>Back by ${esc(new Date(t.deadline).toLocaleString())}</p><a class="primary button wide" href="${esc(t.url)}">${t.safe?'View trip':'Open trip / check in'}</a></article>`).join(''):'<p class="empty">Nothing yet. Your trips will appear here.</p>'}<button class="secondary wide" data-action="demo">Launch a fictional demo trip</button><button class="secondary wide" data-action="profile">Edit my profile</button>`;bind();
}
function counter(label,key,n,unit){return `<label>${label}</label><div class="counter"><button type="button" data-count="${key}" data-delta="-1" aria-label="Decrease ${label}">−</button><strong>${n}<small>${unit}</small></strong><button type="button" data-count="${key}" data-delta="1" aria-label="Increase ${label}">＋</button></div>`;}
function renderPlan(){
 let body='';const titles=['How long are you going?','Where are you going?','What are you taking?',"Who’s going?"];
 const subs=['Choose when you leave and when your contact should expect you back.','Mark each day’s route and your parking spot.','The basics help your contact know what you have with you.','Invite app users after creating your plan, or add companions here.'];
 if(step===0)body=input('Trip name','name',trip.name,'text',true)+counter('Trip length','duration',trip.duration,'days')+input('Leaving','departureLocal',trip.departureLocal,'datetime-local',true)+input('Back by','deadlineLocal',trip.deadlineLocal,'datetime-local',true)+chips('What kind of trip?','activity',['Hiking','Backpacking','Canoeing','Kayaking','Skiing','Other'],trip.activity)+`<p class="small">Times use your device’s time zone.</p>`;
 if(step===1)body=`<div class="chips"><button type="button" class="chip ${mode==='route'?'selected':''}" data-mode="route">Route</button><button type="button" class="chip ${mode==='parking'?'selected':''}" data-mode="parking">Parking</button><button type="button" class="chip" data-action="locate">◎ Locate me</button></div><div class="map-stage"><div id="map" aria-label="Route editor map"></div><span class="map-mode">${mode==='parking'?'Click to place parking':drawMode?'Drag to draw your route':'Click to add a waypoint'}</span></div><p id="map-network" class="alert small" hidden></p><p id="route-metrics" class="route-metrics"></p><div class="map-jump"><label>Go to coordinates<input id="map-coordinate" placeholder="37.380, -80.089" aria-label="Map center coordinates"></label><button type="button" class="secondary" data-action="jump">Go</button><button type="button" class="secondary" data-action="fit">Fit route</button></div><p id="map-help" class="small">${window.L?'Click to add points. Enable drawing to drag a rough route. Lines do not follow trails.':'Map could not load. You can still save a written itinerary below.'}</p><div class="chips">${trip.days.map((d,i)=>`<button type="button" class="chip ${i===day?'selected':''}" data-day="${i}">Day ${i+1} · ${d.length}</button>`).join('')}</div><button type="button" class="secondary" data-action="drawing">${drawMode?'Stop drawing':'Draw route'}</button><button type="button" class="secondary" data-action="undo">Undo</button><button type="button" class="secondary" data-action="clearDay">Clear day</button>`+area('Route, campsites, and alternate plans','route',trip.route,true)+area('Vehicle and exact parking location','vehicle',trip.vehicle);
 if(step===2)body=counter('Food','food',trip.food,'days of food')+chips('Shelter','shelter',['Tent','Hammock','Tarp','Bivy','Cabin or hut','None'],trip.shelter)+chips('Shelter color','shelterColor',['Orange','Yellow','Red','Blue','Green','Tan'],trip.shelterColor)+`<label class="check"><input type="checkbox" data-key="messenger" ${trip.messenger?'checked':''}> Satellite messenger or beacon</label>`+area('Other equipment / communication details','equipmentNotes',trip.equipmentNotes||'');
 if(step===3)body=chips('Group','groupMode',['Just me','A group'],trip.groupMode)+`<div class="contact-card">${esc(profile.name)} <span class="muted">· Organizer</span></div>`+(trip.groupMode==='A group'?area('Add people without the app (names and useful details)','group',trip.group)+`<p class="small">An invitation link will be available after you create the plan. Each app user joins with their own profile and chooses whether to share health details.</p>`:'');
 frame(titles[step],subs[step],body,step===3?'Review and send →':'Next →');
 if(step===1)initMap();
}
function initMap(){
 if(!window.L)return;
 map=TrailMaps.create('map',mapView?.center||trip.parking||trip.days.flat()[0]||[37.38,-80.08],mapView?.zoom||12);
 layers=L.layerGroup().addTo(map);
 map.on('click',e=>{if(drawMode)return;if(mode==='parking')trip.parking=[e.latlng.lat,e.latlng.lng];else if(trip.days[day].length<200)trip.days[day].push([e.latlng.lat,e.latlng.lng]);drawMap();});
 if(drawMode){map.dragging.disable();map.boxZoom.disable();}
 map.getContainer().classList.toggle('is-drawing',drawMode);
 const container=map.getContainer();container.style.touchAction=drawMode?'none':'';
 let tracing=false;
 container.addEventListener('pointerdown',e=>{if(!drawMode||e.target.closest('.leaflet-control'))return;tracing=true;container.setPointerCapture(e.pointerId);addDraw(e);});
 container.addEventListener('pointermove',e=>{if(tracing)addDraw(e);});
 container.addEventListener('pointerup',()=>tracing=false);
 container.addEventListener('pointercancel',()=>tracing=false);
 function addDraw(e){if(trip.days[day].length>=200)return;const p=map.mouseEventToLatLng(e),last=trip.days[day].at(-1);if(!last||map.latLngToContainerPoint(last).distanceTo(map.latLngToContainerPoint(p))>9){trip.days[day].push([p.lat,p.lng]);drawMap();}}
 drawMap();const all=trip.days.flat();if(!mapView&&all.length>1)map.fitBounds(all,{padding:[25,25]});
}
function drawMap(){if(!map)return;layers.clearLayers();const colors=['#b8522b','#386d65','#8f6d9b','#947124'];trip.days.forEach((points,i)=>{L.polyline(points,{color:colors[i%4],weight:i===day?5:3}).addTo(layers);if(points.length)L.circleMarker(points.at(-1),{radius:7,color:colors[i%4]}).bindTooltip(`Day ${i+1} end`).addTo(layers);});if(trip.parking)L.marker(trip.parking,{draggable:true}).bindTooltip('Parking').on('dragend',e=>{const p=e.target.getLatLng();trip.parking=[p.lat,p.lng];drawMap();}).addTo(layers);const metrics=document.getElementById('route-metrics');if(metrics)metrics.textContent=`Day ${day+1}: ${trip.days[day].length} points · ${TrailMaps.distance(trip.days[day])} mi approximate straight-line distance`;root.querySelectorAll('[data-day]').forEach(el=>el.textContent=`Day ${Number(el.dataset.day)+1} · ${trip.days[el.dataset.day].length}`);}
function renderReview(){step=4;const rows=[['TRIP',`${trip.activity} · ${trip.duration} days`,`${new Date(trip.departureLocal).toLocaleString()} → ${new Date(trip.deadlineLocal).toLocaleString()}`],['ROUTE',`${trip.days.filter(d=>d.length).length} days marked`,trip.route],['TAKING',`${trip.food} days of food`,`${trip.shelterColor} ${trip.shelter.toLowerCase()}${trip.messenger?' · Satellite messenger':''}`],['GOING',trip.groupMode==='Just me'?profile.name:`${profile.name} and companions`,trip.groupMode==='A group'?trip.group:'']];frame('Review your plan','Tap any section to change it.',`<div class="review-list">${rows.map((r,i)=>`<button type="button" data-edit="${i}"><span class="eyebrow">${r[0]}</span><strong>${esc(r[1])}</strong><small>${esc(r[2])}</small><b>›</b></button>`).join('')}</div>`,'Choose who to send it to →');const bottom=root.querySelector('.wizard-bottom');bottom.insertAdjacentHTML('beforebegin',reviewPanel());bindReview();}
function renderSend(){step=4;frame('Send your plan','Create a link, then share it with your chosen contacts.',`<label>Send to · up to two people</label>${profile.contacts.map((c,i)=>`<label class="contact-choice"><input type="checkbox" data-contact="${i}" ${trip.selected.includes(i)?'checked':''}><span><strong>${esc(c.name)}</strong><small>${esc(c.relationship||'Emergency contact')}</small></span></label>`).join('')}<button type="button" class="secondary" data-action="other">${trip.other?'Use saved contacts':'Choose someone else'}</button>${trip.other?input('Contact name','otherName',trip.otherName,'text',true)+input('Phone','otherPhone',trip.otherPhone,'tel')+input('Email','otherEmail',trip.otherEmail,'email'):''}${chips('How to share','channel',['Text','Email','Link'],trip.channel)}<label class="check"><input type="checkbox" data-key="include_health" ${trip.include_health?'checked':''}> Include my health details</label><p class="small">${trip.include_health?'Anyone with a selected contact’s link will be able to read the included health details.':'Your health details will not be included in the trip packet.'}</p>${area('Agreed overdue instructions','instructions',trip.instructions,true)}<p class="small">Write the steps agreed with your contact if you do not return on time.</p><div class="message-preview">${esc(messagePreview())}</div>`,'Create plan and prepare sharing →');}
function messagePreview(){return `Heading out ${trip.activity.toLowerCase()} for ${trip.duration} days. Back by ${new Date(trip.deadlineLocal).toLocaleString()}. Please read my plan and acknowledge it using the link.`;}
function renderReady(){
 root.innerHTML=`<div class="success-mark">✓</div><h1>Your plan is ready.</h1><p class="muted">Share each contact’s link below. Opening a message draft does not confirm that it was sent.</p><div id="error" class="alert" hidden></div>${result.contacts.map((c,i)=>`<section class="contact-card"><h2>${esc(c.name)}</h2><label>Contact link<input readonly value="${esc(c.url)}"></label><button class="secondary" data-copy="${i}">Copy link</button>${trip.channel==='Text'&&c.phone?`<a class="primary button" href="sms:${esc(c.phone.replace(/[^+\d]/g,''))}?body=${encodeURIComponent(messagePreview()+' '+c.url)}">Open text message</a>`:''}${trip.channel==='Email'&&c.email?`<a class="primary button" href="mailto:${encodeURIComponent(c.email)}?subject=My%20Trailhead%20trip%20plan&body=${encodeURIComponent(messagePreview()+' '+c.url)}">Open email draft</a>`:''}${trip.channel==='Text'&&!c.phone||trip.channel==='Email'&&!c.email?'<p class="small">No address for this sharing method. Copy and share the link instead.</p>':''}</section>`).join('')}${trip.groupMode==='A group'?`<section class="contact-card"><h2>Invite your group</h2><p>Share this invitation with companions who will join using their own profile.</p><input readonly value="${esc(result.invite)}"><button class="secondary" data-copy="invite">Copy group invitation</button></section>`:''}<a class="primary button wide" href="${esc(result.url)}">Open trip and check-in controls →</a><button class="secondary wide" data-action="home">Back to home</button><p class="small">Health details: ${trip.include_health?'included':'not shared'}. Acknowledgment is shown on your trip page.</p>`;bind();
}
function bind(){
 const form=document.getElementById('wizard');if(form)form.onsubmit=next;
 root.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>action(b.dataset.action));
 root.querySelectorAll('[data-choice]').forEach(b=>b.onclick=()=>{collect();(screen==='profile'?profile:trip)[b.dataset.choice]=b.dataset.value;render();});
 root.querySelectorAll('[data-count]').forEach(b=>b.onclick=()=>{collect();const key=b.dataset.count;trip[key]=Math.min(30,Math.max(key==='food'?0:1,Number(trip[key])+Number(b.dataset.delta)));if(key==='duration'){while(trip.days.length<trip.duration)trip.days.push([]);trip.days.length=trip.duration;day=Math.min(day,trip.duration-1);const end=new Date(trip.departureLocal);end.setDate(end.getDate()+trip.duration-1);end.setHours(18);trip.deadlineLocal=localDate(end);}render();});
 root.querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{collect();day=Number(b.dataset.day);render();});
 root.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{collect();mode=b.dataset.mode;drawMode=false;render();});
 root.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>{screen='plan';step=Number(b.dataset.edit);render();});
 root.querySelectorAll('[data-contact]').forEach(b=>b.onchange=()=>{trip.selected=[...root.querySelectorAll('[data-contact]:checked')].map(e=>Number(e.dataset.contact));});
 const health=root.querySelector('[data-key="include_health"]');if(health)health.onchange=()=>{collect();render();};
 root.querySelectorAll('[data-copy]').forEach(b=>b.onclick=async()=>{const value=b.dataset.copy==='invite'?result.invite:result.contacts[Number(b.dataset.copy)].url;try{await navigator.clipboard.writeText(value);b.textContent='Copied';}catch{b.textContent='Select and copy the link above';}});
}
async function action(a){
 if(document.getElementById('wizard'))collect();
 if(a==='new'){mapView=null;trip=newTrip();screen='plan';step=0;}
 if(a==='profile'){screen='profile';step=0;}
 if(a==='home'){try{me=await api('/api/me');screen='home';}catch(e){error(e.message);return;}}
 if(a==='back'){if(screen==='profile'){if(step)step--;else if(me.profile)screen='home';}else if(screen==='plan'){if(step)step--;else screen='home';}else if(screen==='review'){screen='plan';step=3;}else if(screen==='send')screen='review';}
 if(a==='addContact')profile.contacts.push({});
 if(a==='removeContact')profile.contacts.pop();
 if(a==='other')trip.other=!trip.other;
 if(a==='drawing'){mode='route';drawMode=!drawMode;}
 if(a==='undo'){if(mode==='parking')trip.parking=null;else trip.days[day].pop();drawMap();return;}
 if(a==='clearDay'){trip.days[day]=[];drawMap();return;}
 if(a==='jump'){const parts=document.getElementById('map-coordinate').value.split(',').map(Number);if(parts.length!==2||!parts.every(Number.isFinite)||Math.abs(parts[0])>85||Math.abs(parts[1])>180){error('Enter latitude, longitude, for example 37.380, -80.089.');return;}if(map)map.setView(parts,14);return;}
 if(a==='fit'){const all=trip.days.flat().concat(trip.parking?[trip.parking]:[]);if(map&&all.length)map.fitBounds(all,{padding:[35,35],maxZoom:15});return;}
 if(a==='demo'){try{const d=await api('/api/demo',{});location.href=d.url;}catch(e){error(e.message);}return;}
 if(a==='locate'){if(navigator.geolocation)navigator.geolocation.getCurrentPosition(p=>map&&map.setView([p.coords.latitude,p.coords.longitude],14),()=>error('Location unavailable. Pan the map to your trailhead.'));return;}
 render();
}
async function next(event){
 event.preventDefault();if(busy||!valid())return;
 if(screen==='profile'){
  if(step<3){step++;render();return;}
  busy=true;try{await api('/api/profile',profile);me=await api('/api/me');profile=me.profile;screen='setupDone';render();}catch(e){error(e.message);}finally{busy=false;}return;
 }
 if(screen==='plan'){
  if(step===0){if(new Date(trip.deadlineLocal)<=new Date(trip.departureLocal)){error('Return time must be after departure.');return;}const first=new Date(trip.departureLocal.slice(0,10)+'T12:00'),last=new Date(trip.deadlineLocal.slice(0,10)+'T12:00');trip.duration=Math.round((last-first)/86400000)+1;if(trip.duration>30){error('Choose a trip of up to 30 days.');return;}while(trip.days.length<trip.duration)trip.days.push([]);trip.days.length=trip.duration;}
  if(step<3)step++;else screen='review';render();return;
 }
 if(screen==='review'){screen='send';render();return;}
 if(screen==='send'){
  const contacts=trip.other?[{name:trip.otherName||'',phone:trip.otherPhone||'',email:trip.otherEmail||''}]:trip.selected.map(i=>profile.contacts[i]);
  if(!contacts.length){error('Choose at least one contact.');return;}
  busy=true;root.querySelector('button.primary').disabled=true;
  try{result=await api('/api/trips',{...trip,departure:new Date(trip.departureLocal).toISOString(),deadline:new Date(trip.deadlineLocal).toISOString(),equipment:`${trip.food} days of food. ${trip.shelterColor} ${trip.shelter}. Satellite messenger: ${trip.messenger?'yes':'no'}. ${trip.equipmentNotes||''}`,group:trip.groupMode==='Just me'?profile.name:trip.group,contacts});screen='ready';render();}catch(e){error(e.message);root.querySelector('button.primary').disabled=false;}finally{busy=false;}
 }
}
async function start(){try{me=await api('/api/me');profile=me.profile||{contacts:[{}]};screen=me.profile?(location.hash==='#profile'?'profile':'home'):'profile';render();}catch(e){root.textContent=e.message;}}
window.addEventListener('hashchange',()=>{if(location.hash==='#profile'){screen='profile';step=0;render();}});
start();
