'use strict';
function reviewPanel(){
 const checks=[
  {label:'Written itinerary',done:!!trip.route.trim(),step:1},
  {label:'Parking location marked',done:!!trip.parking,step:1},
  {label:'Every day has a route',done:trip.days.every(d=>d.length>1),step:1},
  {label:'Food covers the trip length',done:Number(trip.food)>=Number(trip.duration),step:2},
  {label:'Companions identified',done:trip.groupMode==='Just me'||!!trip.group.trim(),step:3}
 ];
 return `<section class="preflight"><span class="eyebrow">TRAILHEAD PREFLIGHT</span><h2>A clearer plan before you go.</h2><p class="small">Rules-based completeness checks. This is not a safety rating or route assessment.</p>${checks.map(c=>`<button type="button" class="check-row" data-review-edit="${c.step}"><span>${c.done?'✓':'○'} ${c.label}</span><small>${c.done?'Added':'Review →'}</small></button>`).join('')}<p class="small">Your contact still needs to acknowledge the plan after you share it.</p><button type="button" class="secondary wide" id="ai-review">Explain these gaps with AI</button><p class="small">Optional: sends only activity, trip length, and checklist results to Google Gemini. No names, health data, route text, or coordinates.</p><div id="ai-result" class="preserve" aria-live="polite"></div></section>`;
}
function bindReview(){
 root.querySelectorAll('[data-review-edit]').forEach(b=>b.onclick=()=>{screen='plan';step=Number(b.dataset.reviewEdit);render();});
 const button=document.getElementById('ai-review');button.onclick=async()=>{
  button.disabled=true;button.textContent='Reviewing…';
  try{
   const response=await api('/api/review',{activity:trip.activity,duration:Number(trip.duration),food:Number(trip.food),route_written:!!trip.route.trim(),parking_marked:!!trip.parking,all_days_mapped:trip.days.every(d=>d.length>1),companions_named:trip.groupMode==='Just me'||!!trip.group.trim()});
   document.getElementById('ai-result').textContent=response.text;
   button.textContent=response.provider==='gemini'?'Gemini review complete':'Rules-based review (AI not connected)';
  }catch(e){document.getElementById('ai-result').textContent=e.message;button.textContent='Retry review';}
  finally{button.disabled=false;}
 };
}
