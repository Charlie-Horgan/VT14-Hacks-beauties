import json
import os
import secrets
import sqlite3
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta
from flask import Flask, render_template, request, redirect, url_for, abort, session, jsonify

app = Flask(__name__)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', MAX_CONTENT_LENGTH=2 * 1024 * 1024)
secret_path = os.path.join(app.root_path, '.session-secret')
if not os.environ.get('SECRET_KEY') and not os.path.exists(secret_path):
    with open(secret_path, 'w') as secret_file:
        secret_file.write(secrets.token_hex(32))
app.secret_key = os.environ.get('SECRET_KEY') or open(secret_path).read()
app.permanent_session_lifetime = timedelta(days=365)
DB = os.environ.get('TRAILHEAD_DB', 'trailhead.sqlite3')

def connect():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.execute('CREATE TABLE IF NOT EXISTS trips (id TEXT PRIMARY KEY, owner TEXT, contact TEXT, data TEXT, accepted INTEGER DEFAULT 0, safe INTEGER DEFAULT 0, demo INTEGER DEFAULT 0)')
    db.execute('CREATE TABLE IF NOT EXISTS profiles (id TEXT PRIMARY KEY, data TEXT NOT NULL)')
    db.execute('CREATE TABLE IF NOT EXISTS owned_trips (profile TEXT, owner TEXT UNIQUE)')
    db.execute('CREATE TABLE IF NOT EXISTS trip_contacts (token TEXT PRIMARY KEY, owner TEXT, name TEXT, accepted INTEGER DEFAULT 0)')
    db.execute('CREATE TABLE IF NOT EXISTS invites (token TEXT PRIMARY KEY, owner TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS members (owner TEXT, profile TEXT, data TEXT, UNIQUE(owner, profile))')
    db.execute('CREATE TABLE IF NOT EXISTS events (owner TEXT, kind TEXT, detail TEXT, at TEXT)')
    return db

def get_trip(token, role):
    with connect() as db:
        row = db.execute(f'SELECT * FROM trips WHERE {role}=?', (token,)).fetchone()
    if not row and role == 'contact':
        with connect() as db:
            row = db.execute('SELECT trips.* FROM trips JOIN trip_contacts ON trips.owner=trip_contacts.owner WHERE trip_contacts.token=?', (token,)).fetchone()
    if not row:
        abort(404)
    trip = dict(row)
    trip['data'] = json.loads(trip['data'])
    trip['overdue'] = bool(trip['demo']) or datetime.now(timezone.utc) > datetime.fromisoformat(trip['data']['deadline'])
    with connect() as db:
        contacts = [dict(c) for c in db.execute('SELECT name,accepted,token FROM trip_contacts WHERE owner=?', (trip['owner'],))]
        members = [json.loads(m['data']) for m in db.execute('SELECT data FROM members WHERE owner=?', (trip['owner'],))]
    if role == 'owner':
        with connect() as db:
            invite = db.execute('SELECT token FROM invites WHERE owner=?', (trip['owner'],)).fetchone()
        trip['invite'] = invite['token'] if invite else None
    trip['contacts'] = contacts
    trip['members'] = members
    if contacts:
        trip['accepted'] = all(c['accepted'] for c in contacts)
        if role == 'contact':
            contact = next((c for c in contacts if c['token'] == token), None)
            if contact:
                trip['accepted'] = contact['accepted']
                trip['data']['contact_name'] = contact['name']
    return trip

@app.after_request
def privacy(response):
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    return response

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'GET':
        return render_template('create.html')
    error = None
    if request.method == 'POST':
        data = {k: request.form.get(k, '').strip() for k in ['name', 'activity', 'leader', 'group', 'route', 'vehicle', 'equipment', 'instructions', 'contact_name', 'departure', 'deadline', 'points']}
        try:
            departure = datetime.fromisoformat(data['departure'].replace('Z', '+00:00'))
            deadline = datetime.fromisoformat(data['deadline'].replace('Z', '+00:00'))
            if not departure.tzinfo or not deadline.tzinfo or deadline <= departure:
                raise ValueError('Return time must be after departure.')
            if not all(data[k] for k in ['name', 'leader', 'route', 'contact_name', 'instructions']):
                raise ValueError('Complete the required trip details.')
            points = json.loads(data['points'] or '[]')
            if not isinstance(points, list) or len(points) > 200 or any(not isinstance(p, list) or len(p) != 2 or not all(isinstance(v, (float, int)) for v in p) or not (-90 <= p[0] <= 90 and -180 <= p[1] <= 180) for p in points):
                raise ValueError('Invalid map coordinates.')
            data['points'] = points
            data['deadline'] = deadline.isoformat()
            owner, contact = secrets.token_urlsafe(24), secrets.token_urlsafe(24)
            with connect() as db:
                db.execute('INSERT INTO trips(id,owner,contact,data) VALUES(?,?,?,?)', (secrets.token_hex(12), owner, contact, json.dumps(data)))
            return redirect(url_for('organizer', token=owner))
        except (ValueError, TypeError) as exc:
            error = str(exc)
    return render_template('create.html', error=error)

@app.route('/trip/<token>', methods=['GET', 'POST'])
def organizer(token):
    trip = get_trip(token, 'owner')
    if request.method == 'POST':
        action = request.form.get('action')
        with connect() as db:
            if action == 'safe':
                db.execute('UPDATE trips SET safe=1 WHERE owner=?', (token,))
            elif action in ['demo', 'reset'] and not trip['safe']:
                db.execute('UPDATE trips SET demo=? WHERE owner=?', (int(action == 'demo'), token))
        if action in ['safe','demo','reset']:
            log_event(token, action, {'safe':'Organizer checked in safely','demo':'Overdue simulation started','reset':'Overdue simulation ended'}[action])
        return redirect(url_for('organizer', token=token))
    return render_template('trip.html', trip=trip, watcher=False)

@app.route('/watch/<token>', methods=['GET', 'POST'])
def watcher(token):
    trip = get_trip(token, 'contact')
    if request.method == 'POST':
        with connect() as db:
            db.execute('UPDATE trips SET accepted=1 WHERE contact=?', (token,))
            db.execute('UPDATE trip_contacts SET accepted=1 WHERE token=?', (token,))
        log_event(trip['owner'], 'acknowledged', trip['data']['contact_name'] + ' acknowledged the plan')
        return redirect(url_for('watcher', token=token))
    return render_template('trip.html', trip=trip, watcher=True)


@app.before_request
def browser_identity():
    session.permanent = True
    if 'profile_id' not in session:
        session['profile_id'] = secrets.token_urlsafe(24)
    if 'csrf' not in session:
        session['csrf'] = secrets.token_urlsafe(24)
    if request.method == 'POST':
        supplied = request.headers.get('X-CSRF-Token') or request.form.get('csrf')
        if not supplied or not secrets.compare_digest(supplied, session['csrf']):
            abort(400, 'Please reload the page before submitting.')


def profile_data():
    with connect() as db:
        row = db.execute('SELECT data FROM profiles WHERE id=?', (session['profile_id'],)).fetchone()
    return json.loads(row['data']) if row else None


def short(value, limit=5000):
    if not isinstance(value, str):
        raise ValueError('A text field has an invalid value.')
    return value.strip()[:limit]


def coordinates(value):
    if not isinstance(value, list) or len(value) > 200:
        raise ValueError('Use at most 200 points per day.')
    for point in value:
        if not isinstance(point, list) or len(point) != 2 or any(type(n) not in (int, float) for n in point) or not (-90 <= point[0] <= 90 and -180 <= point[1] <= 180):
            raise ValueError('Invalid map point.')
    return value


@app.get('/api/me')
def me():
    with connect() as db:
        tokens = [r['owner'] for r in db.execute('SELECT owner FROM owned_trips WHERE profile=? ORDER BY rowid DESC', (session['profile_id'],))]
    trips = []
    for token in tokens:
        t = get_trip(token, 'owner')
        trips.append({'name': t['data']['name'], 'activity': t['data']['activity'], 'deadline': t['data']['deadline'], 'safe': t['safe'], 'accepted': t['accepted'], 'overdue': t['overdue'], 'url': url_for('organizer', token=token)})
    return jsonify(profile=profile_data(), trips=trips)


@app.post('/api/profile')
def save_profile():
    raw = request.get_json(silent=True) or {}
    try:
        data = {k: short(raw.get(k, '')) for k in ['name','dob','phone','email','allergies','conditions','medications','height','blood','make','model','color','plate','state','vehicle_notes']}
        if not data['name']:
            raise ValueError('Enter your name.')
        contacts = raw.get('contacts', [])
        if not isinstance(contacts, list) or not 1 <= len(contacts) <= 2:
            raise ValueError('Add one or two emergency contacts.')
        data['contacts'] = []
        for c in contacts:
            entry = {k: short(c.get(k, '')) for k in ['name','relationship','phone','email']}
            if not entry['name'] or not (entry['phone'] or entry['email']):
                raise ValueError('Each contact needs a name and phone or email.')
            data['contacts'].append(entry)
        with connect() as db:
            db.execute('INSERT OR REPLACE INTO profiles(id,data) VALUES(?,?)', (session['profile_id'], json.dumps(data)))
        return jsonify(ok=True)
    except (ValueError, TypeError, AttributeError) as exc:
        return jsonify(error=str(exc)), 400


@app.post('/api/trips')
def create_trip():
    raw = request.get_json(silent=True) or {}
    p = profile_data()
    if not p:
        return jsonify(error='Complete your profile first.'), 400
    try:
        data = {k: short(raw.get(k, '')) for k in ['name','activity','route','vehicle','equipment','instructions','departure','deadline','group']}
        departure = datetime.fromisoformat(data['departure'].replace('Z','+00:00'))
        deadline = datetime.fromisoformat(data['deadline'].replace('Z','+00:00'))
        if not departure.tzinfo or not deadline.tzinfo or deadline <= departure:
            raise ValueError('Return time must be after departure.')
        if not all(data[k] for k in ['name','route','instructions']):
            raise ValueError('Add a trip name, itinerary, and overdue instructions.')
        days = raw.get('days', [])
        if not isinstance(days, list) or not 1 <= len(days) <= 30:
            raise ValueError('Choose between 1 and 30 days.')
        data['days'] = [coordinates(day) for day in days]
        parking = raw.get('parking')
        data['parking'] = coordinates([parking])[0] if parking is not None else None
        data['points'] = [point for day in data['days'] for point in day]
        data['leader'] = p['name']
        data['deadline'] = deadline.isoformat()
        contacts = raw.get('contacts', [])
        if not isinstance(contacts,list) or not 1 <= len(contacts) <= 2:
            raise ValueError('Choose one or two contacts.')
        selected = []
        for c in contacts:
            entry = {k: short(c.get(k,'')) for k in ['name','phone','email']}
            if not entry['name']:
                raise ValueError('Enter a contact name.')
            selected.append(entry)
        data['contact_name'] = ', '.join(c['name'] for c in selected)
        data['health'] = {k:p.get(k,'') for k in ['allergies','conditions','medications','height','blood','dob']} if raw.get('include_health') is True else None
        data['leader_phone'] = p.get('phone','')
        data['leader_email'] = p.get('email','')
        owner = secrets.token_urlsafe(24)
        invite = secrets.token_urlsafe(24)
        tokens = [secrets.token_urlsafe(24) for c in selected]
        with connect() as db:
            db.execute('INSERT INTO trips(id,owner,contact,data) VALUES(?,?,?,?)', (secrets.token_hex(12),owner,tokens[0],json.dumps(data)))
            db.execute('INSERT INTO owned_trips VALUES(?,?)',(session['profile_id'],owner))
            db.execute('INSERT INTO invites VALUES(?,?)',(invite,owner))
            for c, token in zip(selected,tokens):
                db.execute('INSERT INTO trip_contacts(token,owner,name) VALUES(?,?,?)',(token,owner,c['name']))
        result = [{'name':c['name'],'phone':c['phone'],'email':c['email'],'url':url_for('watcher',token=token,_external=True)} for c,token in zip(selected,tokens)]
        log_event(owner, 'created', 'Trip plan created')
        return jsonify(url=url_for('organizer',token=owner), contacts=result, invite=url_for('join_trip',token=invite,_external=True))
    except (ValueError, TypeError, AttributeError) as exc:
        return jsonify(error=str(exc)),400


@app.route('/join/<token>', methods=['GET','POST'])
def join_trip(token):
    with connect() as db:
        invite = db.execute('SELECT owner FROM invites WHERE token=?',(token,)).fetchone()
    if not invite:
        abort(404)
    trip = get_trip(invite['owner'],'owner')
    p = profile_data()
    if request.method == 'POST':
        if not p or trip['safe']:
            abort(400)
        member = {'name':p['name'], 'phone':p['phone'], 'health': {k:p.get(k,'') for k in ['allergies','conditions','medications','height','blood']} if request.form.get('health') == 'yes' else None}
        with connect() as db:
            db.execute('INSERT OR REPLACE INTO members VALUES(?,?,?)',(trip['owner'],session['profile_id'],json.dumps(member)))
        return render_template('join.html',trip=trip,profile=p,joined=True)
    return render_template('join.html',trip=trip,profile=p,joined=False)


def log_event(owner, kind, detail):
    with connect() as db:
        db.execute('INSERT INTO events VALUES(?,?,?,?)', (owner,kind,detail,datetime.now(timezone.utc).isoformat()))


@app.get('/api/status/<role>/<token>')
def trip_status(role, token):
    if role not in ('owner','contact'):
        abort(404)
    trip=get_trip(token,role)
    with connect() as db:
        events=[dict(r) for r in db.execute('SELECT kind,detail,at FROM events WHERE owner=? ORDER BY rowid DESC LIMIT 12',(trip['owner'],))]
    return jsonify(safe=bool(trip['safe']),overdue=trip['overdue'],demo=bool(trip['demo']),accepted=bool(trip['accepted']),members=len(trip['members']),contacts=[{'name':c['name'],'accepted':bool(c['accepted'])} for c in trip['contacts']],events=events)


@app.post('/api/review')
def plan_review():
    raw=request.get_json(silent=True) or {}
    if not isinstance(raw,dict):
        return jsonify(error='Invalid review request.'),400
    # Only an allowlisted non-identifying checklist reaches the model.
    activity=raw.get('activity') if raw.get('activity') in ['Hiking','Backpacking','Canoeing','Kayaking','Skiing','Other'] else 'Other'
    try:
        length=max(1,min(30,int(raw.get('duration',1))))
        food=max(0,min(30,int(raw.get('food',0))))
    except (ValueError,TypeError):
        return jsonify(error='Invalid trip length.'),400
    gaps=[]
    for key,label in [('route_written','Add a written itinerary and alternate plan.'),('parking_marked','Mark the parking location.'),('all_days_mapped','Mark a planned route for each day.'),('companions_named','Identify the people going with you.')]:
        if raw.get(key) is not True:gaps.append(label)
    if food<length:gaps.append('Review food quantity: the entered food days are fewer than trip days.')
    fallback='\n'.join(gaps) if gaps else 'The checked planning fields are complete. Confirm the route and local conditions separately, and ask your contact to acknowledge the plan.'
    key=os.environ.get('GEMINI_API_KEY')
    if not key:
        return jsonify(provider='rules',text='AI is not connected. Checklist review:\n\n'+fallback)
    last=session.get('last_ai_review',0)
    now=datetime.now(timezone.utc).timestamp()
    if now-last<10:
        return jsonify(provider='rules',text='Please wait a few seconds before another AI request.\n\n'+fallback)
    session['last_ai_review']=now
    payload={'model':os.environ.get('GEMINI_MODEL','gemini-3.8-flash'),'system_instruction':'You explain missing fields in an outdoor trip plan. Use only the supplied checklist. Give at most four short sentences with practical questions to clarify the missing information. Do not invent locations, conditions, phone numbers, medical advice, risk scores, or rescue instructions. Never certify a trip safe. Remind the reader to agree on a return deadline with their contact.','input':json.dumps({'activity':activity,'trip_days':length,'food_days':food,'missing_fields':gaps})}
    req=urllib.request.Request('https://generativelanguage.googleapis.com/v1beta/interactions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','x-goog-api-key':key},method='POST')
    try:
        with urllib.request.urlopen(req,timeout=12) as response:
            answer=json.load(response)
        text=answer.get('output_text') or '\n'.join(item.get('text','') for item in answer.get('outputs',[]) if item.get('type')=='text')
        if not text:raise ValueError('No model response')
        return jsonify(provider='gemini',text=text[:3000])
    except (urllib.error.URLError,ValueError,KeyError,TypeError,TimeoutError):
        return jsonify(provider='rules',text='The AI service is unavailable. Your plan is unchanged. Checklist review:\n\n'+fallback)


@app.post('/api/demo')
def create_demo():
    now=datetime.now(timezone.utc)
    data={'name':'McAfee Knob weekend · DEMO','activity':'Backpacking','leader':'Alex Morgan (fictional)','leader_phone':'555-0100 (fictional)','leader_email':'','group':'Alex Morgan and Jamie Reed (fictional)','route':'Illustrative demo only: Day 1 follows the marked corridor from parking to a planned camp. Day 2 returns along the same corridor. Confirm real trails and camping permissions separately.','vehicle':'Blue hatchback, DEMO plate, illustrative parking pin','equipment':'Orange tent, 3 days of food, headlamps, satellite messenger','instructions':'Fictional demo agreement: try both participants and their satellite contact. If concern remains, follow the agreed escalation plan and provide this packet to the appropriate responders.','contact_name':'Taylor (fictional)','departure':now.isoformat(),'deadline':(now+timedelta(hours=24)).isoformat(),'days':[[[37.380,-80.089],[37.384,-80.081],[37.389,-80.074],[37.392,-80.061]],[[37.392,-80.061],[37.389,-80.074],[37.384,-80.081],[37.380,-80.089]]],'parking':[37.380,-80.089],'health':None}
    data['points']=[p for day in data['days'] for p in day]
    owner,contact,invite=[secrets.token_urlsafe(24) for _ in range(3)]
    with connect() as db:
        db.execute('INSERT INTO trips(id,owner,contact,data) VALUES(?,?,?,?)',(secrets.token_hex(12),owner,contact,json.dumps(data)))
        db.execute('INSERT INTO owned_trips VALUES(?,?)',(session['profile_id'],owner))
        db.execute('INSERT INTO trip_contacts(token,owner,name) VALUES(?,?,?)',(contact,owner,data['contact_name']))
        db.execute('INSERT INTO invites VALUES(?,?)',(invite,owner))
    log_event(owner,'created','Fictional demo plan created')
    return jsonify(url=url_for('organizer',token=owner))


@app.get('/packet/<role>/<token>')
def download_packet(role,token):
    if role not in ('owner','contact'):abort(404)
    trip=get_trip(token,role)
    d=trip['data']
    lines=['TRAILHEAD TRIP PACKET',d['name'],'Status: '+('Checked in safely' if trip['safe'] else 'Return deadline passed' if trip['overdue'] else 'Active plan'),'Return deadline (with timezone): '+d['deadline'],'Planned itinerary only. No live location. No automatic emergency dispatch.','']
    for label,key in [('Leader','leader'),('Leader phone','leader_phone'),('Departure','departure'),('Route','route'),('People','group'),('Vehicle and parking','vehicle'),('Equipment','equipment'),('Agreed overdue instructions','instructions')]:
        lines.extend([label+':',str(d.get(key) or 'Not provided'),''])
    lines.append('Parking coordinates: '+str(d.get('parking') or 'Not marked'))
    for i,points in enumerate(d.get('days',[d['points']])):
        lines.append('Day '+str(i+1)+' planned coordinates: '+json.dumps(points))
    if d.get('health'):
        lines.extend(['Explicitly shared health details:',json.dumps(d['health'],ensure_ascii=False)])
    for member in trip['members']:
        lines.extend(['Joined companion:',json.dumps(member,ensure_ascii=False)])
    return app.response_class('\n'.join(lines),mimetype='text/plain',headers={'Content-Disposition':'attachment; filename="Trailhead-trip-packet.txt"'})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
